#!/bin/sh
/etc/init.d/fdfs_trackerd start /etc/fdfs/tracker.conf
/etc/init.d/fdfs_storaged start  /etc/fdfs/storage.conf
/usr/local/nginx/sbin/nginx -g 'daemon off;'
